from setuptools import setup

setup (
    name="paquete01",
    version="1.0",
    description="paquete para calculos basicos",
    author="Alex",
    packages=["calculos", "calculos.basicos"]
)